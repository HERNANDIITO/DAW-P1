<!--
    Archivo: myProfile.php
    Archivo dedicado a los detalles de perfil de un usuario que es uno mismo
    Creado por: Pablo Hernández García el 20/09/2024
    Historial de cambios:
    20/09/2024 - Creado
    01/10/2024 - Desarrollado
    08/10/2024 - CSS Aplicado
-->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" title="Modo claro"  href="../styles/myProfile.css">
    <!-- night mode -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dark/night.css" title="Modo Noche" id="dark">
    <!-- dislexicos -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dyslexic/myProfile.css" title="Modo para dislexicos" id="dyslexia">
    <!-- big-font -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font/myProfile.css"    title="Modo de letras grandes" id="big_font">
    <!-- big-font-dyslexic -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font-dyslexic/myProfile.css"    title="Modo de letras grandes + dislexia" id="dyslexia_and_big_font">
    <script src="https://kit.fontawesome.com/fb64e90a7d.js" crossorigin="anonymous"></script>
    <script src="../js/common.js"></script>

    <title>myProfile</title>
</head>
<body>
    <?php
        include "../inc/header.php";
    ?>

    <main id="main-content">
        <nav id="userMenu">
            <a href="">
                <i class="fa-solid fa-pencil"></i>
                <span>Modificar mi perfil</span>
            </a>
            <a href="">
                <i class="fa-solid fa-trash"></i>
                <span>Darme de baja</span>
            </a>
            <a href="./myAds.php">
                <i class="fa-solid fa-house"></i>
                <span>Visualizar mis anuncios</span>
            </a>
            <a href="./createAd.php">
                <i class="fa-solid fa-plus"></i>
                <span>Crear un anuncio nuevo</span>
            </a>
            <a href="./myMessages.php">
                <i class="fa-solid fa-message"></i>
                <span>Mis mensajes</span>
            </a>
            <a href="../restricted/brochureRequest.php">
                <i class="fa-solid fa-file-lines"></i>
                <span>Solicitar folleto</span>
            </a>
            <a href="../index.php">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Cerrar sesión</span>
            </a>
            <a href="./addPhoto.php">
                <i class="fa-solid fa-camera"></i>
                <span>Añadir foto a anuncio</span>
            </a>
        </nav>
    </main>

    <?php
        include "../inc/footer.php";
    ?>

<script>
    changeStyle();
    checkCookies();
</script>