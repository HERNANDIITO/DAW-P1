<!--
    Archivo: myMessages.php
    Archivo dedicado a los mensajes que recibe un usuario que es uno mismo
    Creado por: David González Moreno el 02/10/2024
    Historial de cambios:
    02/10/2024 - Creado
    08/10/2024 - CSS Aplicado
-->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" title="Modo claro" id="defult" href="../styles/message.css">
    <!-- night mode -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dark/night.css" title="Modo Noche" id="dark">
    <!-- dislexicos -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dyslexic/myMessages.css"    title="Modo para dislexicos" id="dyslexia">
    <!-- big-font -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font/myMessages.css"    title="Modo de letras grandes" id="big_font">
    <!-- big-font-dyslexic -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font-dyslexic/myMessages.css"    title="Modo de letras grandes + dislexia" id="dyslexia_and_big_font">
    <script src="https://kit.fontawesome.com/fb64e90a7d.js" crossorigin="anonymous"></script>
    <script src="../js/common.js" media="screen" crossorigin="anonymous"></script>
    <title>Mis mensajes</title>
</head>
<body>
    <?php
        include "../inc/header.php";
    ?>
    <main id="main-content">
        <h1 class="title">Propuesta</h1>

        <section class="content">
            <section class="inMessages">
                <h2 class="title">Recibidos</h2>
                <section class="messages">
                    <section class="message">
                        <section class="messageContent">
                            <p>He visto que usted vende un piso en Madrid, me gustaría saber si puedo alquilarlo por unos 3 meses para que Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga consequatur possimus dolorem.</p>
                        </section>
                        <hr class="solid">
                        <section class="messageInfo">
                            <span>12/10/2024</span> <span>Louis Amoeba</span><i class="fa-solid fa-circle-info"></i> 
                        </section>
                    </section>
                    <section class="message">
                        <section class="messageContent">
                            <p>He visto que usted vende un piso en Madrid, me gustaría saber si puedo alquilarlo por unos 3 meses para que Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga consequatur possimus dolorem.</p>
                        </section>
                        <hr class="solid">
                        <section class="messageInfo">
                            <span>12/10/2024</span> <span>Louis Amoeba</span><i class="fa-solid fa-user-group"></i>
                        </section>
                    </section>
                    <section class="message">
                        <section class="messageContent">
                            <p>He visto que usted vende un piso en Madrid, me gustaría saber si puedo alquilarlo por unos 3 meses para que Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga consequatur possimus dolorem.</p>
                        </section>
                        <hr class="solid">
                        <section class="messageInfo">
                            <span>12/10/2024</span> <span>Louis Amoeba</span><i class="fa-solid fa-money-bills"></i> 
                        </section>
                    </section>
                </section>
            </section>
            <section class="outMessages">
                <h2 class="title">Enviados</h2>
                <section class="messages">
                    <section class="message">
                        <section class="messageContent">
                            <p>He visto que usted vende un piso en Madrid, me gustaría saber si puedo alquilarlo por unos 3 meses para que Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga consequatur possimus dolorem.</p>
                        </section>
                        <hr class="solid">
                        <section class="messageInfo">
                            <span>12/10/2024</span> <span>Louis Amoeba</span><i class="fa-solid fa-circle-info"></i> 
                        </section>
                    </section>
                    <section class="message">
                        <section class="messageContent">
                            <p>He visto que usted vende un piso en Madrid, me gustaría saber si puedo alquilarlo por unos 3 meses para que Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga consequatur possimus dolorem.</p>
                        </section>
                        <hr class="solid">
                        <section class="messageInfo">
                            <span>12/10/2024</span> <span>Louis Amoeba</span><i class="fa-solid fa-user-group"></i>
                        </section>
                    </section>
                    <section class="message">
                        <section class="messageContent">
                            <p>He visto que usted vende un piso en Madrid, me gustaría saber si puedo alquilarlo por unos 3 meses para que Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga consequatur possimus dolorem.</p>
                        </section>
                        <hr class="solid">
                        <section class="messageInfo">
                            <span>12/10/2024</span> <span>Louis Amoeba</span><i class="fa-solid fa-money-bills"></i> 
                        </section>
                    </section>
                </section>
            </section>
        </section>
    </main>

    <?php
        include "../inc/footer.php";
    ?>

<script>
    changeStyle();
    checkCookies();
</script>