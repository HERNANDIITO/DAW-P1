<!--
    Archivo: acces_info.php
    En este archivo se recopila la información sobre las modificaciones que se han hecho en el codigo para mejorar la accesibilidad
    Creado por: David González Moreno el 17/10/2024
    Historial de cambios:
    17/10/2024 - Creado
-->


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" media="screen" title="Modo claro"  href="../styles/message.css">
    <!-- night mode -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dark/night.css" title="Modo Noche" id="dark">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- dislexicos -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dyslexic/messageResponse.css"    title="Modo para dislexicos" id="dyslexia">
    <!-- big-font -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font/message.css"   title="Modo de letras grandes" id="big_font">
    <!-- big-font-dyslexic -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font-dyslexic/message.css"    title="Modo de letras grandes + dislexia" id="dyslexia_and_big_font">
    <script src="https://kit.fontawesome.com/fb64e90a7d.js" crossorigin="anonymous"></script>
    <script src="../js/common.js"></script>
    <script src="../js/cookieInfo.js"></script>
    <title>Registro</title>
</head>
<body>
    <?php
        include "../inc/header.php";
    ?>

    <main id="main-content">
        <h1 class="title">Información sobre cookies</h1>
        
        <section class="message">
            <section class="messageContent">
                <h2>Cookies</h2>
                <p>Nuestra página utiliza las cookies única y exclusivamente para almacenar el tema seleccionado.</p>
                <p>Dicha cookie caduca a los 45 días de forma automática.</p>
            </section>
            <hr class="solid">
            <section id="selection"></section>

        </section>
    </main>
    
    <?php
        include "../inc/footer.php";
    ?>

<script>
    changeStyle();
    checkCookies();
    setup();
</script>
<body>