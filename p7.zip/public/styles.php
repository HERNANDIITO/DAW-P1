<!--
    Archivo: login.php
    En este archivo se define el formulario de busqueda avanzada
    Creado por: Pablo Hernández García el 02/11/2024
    Historial de cambios:
    02/11/2024 - Creado
-->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/fb64e90a7d.js" crossorigin="anonymous"></script>
    <script src="../js/common.js"></script>
    
    <link rel="stylesheet" media="screen" title="Modo claro"  href="../styles/myProfile.css">

    <!-- night mode -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dark/night.css" title="Modo Noche" id="dark">
    <!-- dislexicos -->
    <link rel="alternate stylesheet" media="screen" href="../styles/dyslexic/myProfile.css"    title="Modo para dislexicos" id="dyslexia">
    <!-- big-font -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font/myProfile.css"    title="Modo de letras grandes" id="big_font">
    <!-- big-font-dyslexic -->
    <link rel="alternate stylesheet" media="screen" href="../styles/big-font-dyslexic/myProfile.css"    title="Modo de letras grandes + dislexia" id="dyslexia_and_big_font">
    <title>Inicio de sesión</title>
</head>
<body>
    <header class="mainHeader">
        <nav id="navBar">
            <section class="links">
                <a class="navLink" href="/"> <i class="fa-solid fa-house"></i> Inicio</a>
                <a class="navLink" href="/public/search.php"> <i class="fa-solid fa-magnifying-glass"></i> Búsqueda</a>
            </section>
            <section class="profile">
                <a class="navLink" href="/public/login.php"> <i class="fa-solid fa-user"></i> Iniciar sesión </a>
                <a class="navLink" href="/public/register.php"> <i class="fa-solid fa-right-to-bracket"></i> Registrarse </a>
            </section>
        </nav>
    </header>
    <main id="main-content">
        <h2>Selección de estilo</h2>
        <nav id="userMenu">
            <button onclick="selectStyle('dyslexic')">
                <i class="fa-solid fa-question"></i>
                <span>Dislexia</span>
            </button>
            <button onclick="selectStyle('big-font')">
                <i class="fa-solid fa-magnifying-glass"></i>
                <span>Fuente grande</span>
            </button>
            <button onclick="selectStyle('big-font-dyslexic')">
                <i class="fa-solid fa-plus"></i>
                <span>Dislexia + Fuente Grande</span>
            </button>
            <button onclick="selectStyle('default')">
                <i class="fa-solid fa-sun"></i>
                <span>Modo claro</span>
            </button>
            <button onclick="selectStyle('dark')">
                <i class="fa-solid fa-moon"></i>
                <span>Modo oscuro</span>
            </button>
        </nav>
    </main>

    <?php
        include "../inc/footer.php";
    ?>

</body>

<script>
    changeStyle();
    checkCookies();
</script>
</html>