<footer id="footer">
        <img src="../assets/img/logo.png" class="logo">
        <section class="index-column">
            <strong>Contacto</strong>
            <ul>
                <li>contacto@gmail.com</li>
                <li>644 78 58 95</li>
            </ul>
        </section>
</footer>
