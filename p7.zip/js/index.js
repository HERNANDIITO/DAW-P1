 //  para cerrar el modal al hacer clic en el botón
 document.getElementById("closeModalButton").addEventListener("click", function() {
    document.getElementById("errorModal").style.display = "none";
});