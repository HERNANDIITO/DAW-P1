function redirigir() {
    window.location.href = "./viewAd.php";
}